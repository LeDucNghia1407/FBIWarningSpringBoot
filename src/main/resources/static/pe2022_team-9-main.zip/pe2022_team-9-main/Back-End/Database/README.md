# DATABASE LEVEL
- Document to install Database & a script on how to initilize a Demo database to interact
