package PMS;

import java.util.*;

public class Store {
	String store;
	String drug;
	String drugStore;
	Date storeTime;
	int quantity;

String getStore() {
	return store;
}
String getDrug() {
	return drug;
}
String getDrugStore() {
	return drugStore;
}
int getQuantity() {
	return quantity;
}
Date getStoretime(){
	return storeTime;
}
}
