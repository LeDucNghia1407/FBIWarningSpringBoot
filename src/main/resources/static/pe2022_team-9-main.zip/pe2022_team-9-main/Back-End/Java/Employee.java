package PMS;

public class Employee {
	String employeeID;
	String drugStoreID;
	String managerBy;
	String name;
	String email;
	int phone;
	byte permission;
	int salary;

String getEmployeeID() {
	return employeeID;
}
String getDrugStoreID() {
	return drugStoreID;
}
String getManagerBy() {
	return managerBy;
}
String getName() {
	return name;
}
String getEmail() {
	return email;
}
int getPhone() {
	return phone;
}
byte getPermission() {
	return permission;
}
int getSalary() {
	return salary;
}
}


