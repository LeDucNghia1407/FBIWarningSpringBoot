package PMS;

public class Login {
	String loginID;
	String employeeID;
	String password;

String getLoginID() {
	return loginID;
}
String getEmployeeID() {
	return employeeID;
}
String getPassword() {
	return password;
}
}

