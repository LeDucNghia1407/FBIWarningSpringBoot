# JAVA CODE FOR RUNNING THE LOGIC OF OUR APPLICATION
- We create the function to handle the logic of our Application in Java and using Spring Boot to connect to Database via MySQL Server and etc.
