package PMS;

public class DrugStore {
	int drugStoreID;
	int managerID;
	int drugSupplierID;
	String name;
	String address;

int getDrugStoreID() {
	return drugStoreID;
}
int getManagerID() {
	return managerID;
}
int getDrugSupplierID() {
	return drugSupplierID;
}
String getName() {
	return name;
}
String getAddress() {
	return address;
}
}