package PMS;
public class Client {
	int clientID;
	int employeeID;


void setClient() {

}
int getClient() {
	return clientID;
}
int getEmployee() {
	return employeeID;
}
}