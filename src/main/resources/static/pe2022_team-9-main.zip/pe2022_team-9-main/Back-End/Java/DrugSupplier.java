package PMS;

public class DrugSupplier {
	String drugSupplierID;
	String name;
	String address;

String getDrugSupplierID() {
	return drugSupplierID;
}
String getName() {
	return name;
}
String getAddress() {
	return address;
}
}
