package PMS;

public class Manager {
	String managerID;
	String drugStoreID;

String getManagerID() {
	return managerID;
}
String getDrugStoreID() {
	return drugStoreID;
}
}
