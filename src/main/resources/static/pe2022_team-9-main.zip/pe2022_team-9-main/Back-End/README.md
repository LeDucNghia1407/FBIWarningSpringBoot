# Back-End Team

Đào Thiện Tước(13471), username: dttuoc99

Nguyễn Tất Đạt (13816) username: hector898

Lê Đức Nghĩa (14706) username: leducnghia-id 14706

Phạm Văn Phi Long (14555) username: 14555

Võ Nguyễn Thanh Thảo (16223) username: 16223

## Technology:
- Database: MySql
- Logic: Java + Spring Boot

**In here contain the file to the Logic and Database of our System**
