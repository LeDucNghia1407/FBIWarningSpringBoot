# PROGRAMMING EXERCISE 2022 - PROF. HUYNH TRUNG HIEU
# PHARMACY MANAGEMENT SYSTEM

## Team Members:

Lê Thị Ngọc Diệp (16090) (Team Leader)

Đào Thiện Tước(13471) username: dttuoc99

Nguyễn Tất Đạt (13816) username: hector898

Kiều Hoàng Khôi (11264) username: khoikieu1608

Lê Đức Nghĩa (14706) username: leducnghia-id 14706

Phạm Văn Phi Long (14555) username: 14555

Vũ Tiến Danh (15783) username: vutiendanhvgu01

Võ Như Đức Nghĩa (16299) username: vonhuducnghia

Võ Nguyễn Thanh Thảo (16223) username: 16223

### **Project: Pharmacy Management System**
The aim of this project is to develop an application for the effective management of a pharmaceutical store. It helps the pharmacist to maintain the records of the medicines/drugs and supplies sent in by the supplier. The admin who are handling the organization will be responsible to manage the record of the employee. Each employee will be given with a separate username and password. The users can communicate each other by using a built-in messaging system. Pharmacy management system deals with the maintenance of drugs and consumables in the pharmacy unit. It application can generate invoices, bills, receipts etc.

### Front-end Team:
Lê Thị Ngọc Diệp (16090) username:Lethingocdiep

Kiều Hoàng Khôi (11264) username: khoikieu1608

Vũ Tiến Danh (15783) username: vutiendanhvgu01  

Võ Như Đức Nghĩa (16299) username: vonhuducnghia

### Back-end Team:
Đào Thiện Tước(13471), username: dttuoc99

Nguyễn Tất Đạt (13816) username: hector898

Lê Đức Nghĩa (14706) username: leducnghia-id 14706

Phạm Văn Phi Long (14555) username: 14555

Võ Nguyễn Thanh Thảo (16223) username: 16223
